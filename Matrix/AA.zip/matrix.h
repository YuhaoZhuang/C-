#include <stdio.h>	
#include <stdlib.h>

struct matrix {
	int size;
	double **m;
};

double cal(struct matrix newmatrix);


